import math
from dataclasses import dataclass

def _phi(x):
    import math
    return (1.0 + math.erf(x / math.sqrt(2.0))) / 2.0
def _norm_pdf(x):
    import math
    return math.exp(-0.5*x*x) / math.sqrt(2*math.pi)
def d1(S,K,r,q,sigma,t):
    import math
    if sigma<=0 or t<=0: return 0.0
    return (math.log(S/K)+(r-q+0.5*sigma*sigma)*t)/(sigma*math.sqrt(t))
def d2(S,K,r,q,sigma,t):
    import math
    return d1(S,K,r,q,sigma,t)-sigma*math.sqrt(t)
def bs_price(S,K,r,q,sigma,t,typ='C'):
    import math
    if t<=0 or sigma<=0:
        return max(0.0,(S-K) if typ=='C' else (K-S))
    D1,D2=d1(S,K,r,q,sigma,t),d2(S,K,r,q,sigma,t)
    if typ=='C':
        return S*math.exp(-q*t)*_phi(D1)-K*math.exp(-r*t)*_phi(D2)
    return K*math.exp(-r*t)*_phi(-D2)-S*math.exp(-q*t)*_phi(-D1)
@dataclass
class Greeks:
    delta: float
    gamma: float
    theta: float
    vega: float
def bs_greeks(S,K,r,q,sigma,t,typ='C'):
    import math
    if t<=0 or sigma<=0: return Greeks(0,0,0,0)
    D1,D2=d1(S,K,r,q,sigma,t),d2(S,K,r,q,sigma,t)
    pdf=_norm_pdf(D1)
    delta = math.exp(-q*t)*(_phi(D1) if typ=='C' else (_phi(D1)-1.0))
    gamma = math.exp(-q*t)*pdf/(S*sigma*math.sqrt(t))
    first = -(S*math.exp(-q*t)*pdf*sigma)/(2.0*math.sqrt(t))
    theta = first - r*K*math.exp(-r*t)*(_phi(D2) if typ=='C' else -_phi(-D2)) + q*S*math.exp(-q*t)*((_phi(D1)) if typ=='C' else -_phi(-D1))
    vega = S*math.exp(-q*t)*pdf*math.sqrt(t)
    return Greeks(delta,gamma,theta,vega)
