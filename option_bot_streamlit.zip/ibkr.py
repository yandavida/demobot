from dataclasses import dataclass
try:
    from ib_insync import IB, Option, ComboLeg, Contract, LimitOrder
except Exception:
    IB=None

@dataclass
class OrderResult:
    ok: bool
    message: str

def place_condor_IBKR(symbol, expiry, legs, credit_limit, qty=1):
    if IB is None:
        return OrderResult(False, 'ib_insync not available.')
    try:
        ib = IB(); ib.connect('127.0.0.1', 7497, clientId=88)
        combo_legs=[]
        for (k,typ,action) in legs:
            con = Option(symbol, expiry, float(k), typ, 'SMART')
            con = ib.qualifyContracts(con)[0]
            combo_legs.append(ComboLeg(conId=con.conId, ratio=1, action=action, exchange='SMART'))
        combo = Contract(symbol=symbol, secType='BAG', currency='USD', exchange='SMART', comboLegs=combo_legs)
        order = LimitOrder('SELL', qty, float(credit_limit))
        trade = ib.placeOrder(combo, order)
        ib.sleep(2.0)
        status = trade.orderStatus.status
        ib.disconnect()
        return OrderResult(True, f'Submitted. Status={status}')
    except Exception as e:
        return OrderResult(False, f'Error: {e}')
