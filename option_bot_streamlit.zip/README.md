# Option Bot (Streamlit Skeleton)

Educational Iron-Condor desk with Streamlit UI, BS pricing, Greeks & payoff.

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy to Streamlit Cloud
1) Create a **public** GitHub repo and upload all files
2) New app → Repository: `youruser/option-bot`, Branch: `main`, Main file: `app.py`
3) Deploy
